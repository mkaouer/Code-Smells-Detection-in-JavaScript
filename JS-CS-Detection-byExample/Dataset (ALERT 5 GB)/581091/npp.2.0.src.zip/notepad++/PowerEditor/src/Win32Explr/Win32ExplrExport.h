#ifndef W32EXPLR_EXPORT_H
#define W32EXPLR_EXPORT_H

#ifdef WIN32EXPLR_EXPORTS
  #define W32EXPLR_API extern "C" __declspec( dllexport )
#else
  #define W32EXPLR_API extern "C" __declspec( dllimport )
#endif //W32EXPLR_EXPORT

#include <windows.h>

W32EXPLR_API HWND doExplorer(HINSTANCE appInstance,  HWND hParent);

#endif //W32EXPLR_EXPORT_H