

typedef struct 
{
   BOOL bRoot;
   LPITEMIDLIST lpi;
   LPSHELLFOLDER lpsfParent;
   LPITEMIDLIST lpifq;
}LPTVITEMDATA;

