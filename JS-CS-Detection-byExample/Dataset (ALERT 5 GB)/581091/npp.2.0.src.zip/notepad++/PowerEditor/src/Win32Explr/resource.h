//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinExplr32.rc
//
#define IDS_SCCSID                      1
#define IDR_MAINMENU                    101
#define IDC_STATUSBAR                   101
#define IDC_TOOLBAR                     102
#define IDB_TOOLBAR                     103
#define IDR_VIEW_POPUP                  103
#define ID_VIEW_LARGEICONS              104
#define ID_VIEW_SMALLICONS              105
#define IDI_MAINICON                    105
#define ID_VIEW_LISTS                   106
#define ID_VIEW_DETAIL                  107
#define IDC_SPLIT_CURSOR                107
#define IDM_VIEW_LARGEICONS             108
#define IDM_VIEW_SMALLICONS             109
#define IDM_VIEW_LIST                   110
#define IDM_VIEW_DETAIL                 111
#define ID_SPLITTER                     1000
#define ID_TREEVIEW                     1002
#define ID_LISTVIEW                     1003
#define IDM_FILE_EXIT                   40001
#define IDM_SPLIT_HORZ                  40002
#define IDM_SPLIT_VERT                  40003
#define IDM_SPLIT_WIDE                  40004
#define IDM_HELP_ABOUT                  40005
#define IDM_SPLIT_CONSTRAIN             40006
#define IDM_SPLIT_SHOWPOS               40007
#define IDM_SPLIT_SHOWWIDTH             40008
#define IDM_SPLIT_SWAPVIEWS             40009
#define ID_VIEW_REFRESH                 40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           115
#endif
#endif
