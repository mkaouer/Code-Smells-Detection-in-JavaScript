#include "Win32ExplrExport.h"
#include <windows.h>

extern "C" HWND explorer(HINSTANCE appInstance, HWND hParent);


W32EXPLR_API HWND doExplorer(HINSTANCE appInstance,  HWND hParent)
{
	return explorer(appInstance,  hParent);
}

W32EXPLR_API void undoExplorer()
{
	//return explorer(appInstance,  hParent);
}