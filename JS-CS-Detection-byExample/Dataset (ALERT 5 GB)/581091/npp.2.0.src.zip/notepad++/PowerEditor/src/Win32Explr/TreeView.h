
#include <shlobj.h>
#include "ShellFunc.h"

HWND hWndTreeView;

HWND CreateTreeView(HINSTANCE appInstance, HWND	hParent, HWND hSplitter);		// Parent window handle
void InitTreeView();
HTREEITEM InsertDesktopItem(LPSHELLFOLDER lpsf);
HTREEITEM InsertTreeItem(BOOL bRoot,
					   TVINSERTSTRUCT* tvins, 
					   char szBuff[MAX_PATH],
					   HTREEITEM hParent,
					   HTREEITEM hPrev, 
					   LPSHELLFOLDER lpsf,
					   LPITEMIDLIST lpifq,
					   LPITEMIDLIST lpi,
					   BOOL bChildValid);

void PopulateTree(TV_ITEM tvi);
UINT DeleteTreeChildren(HTREEITEM hItem);
