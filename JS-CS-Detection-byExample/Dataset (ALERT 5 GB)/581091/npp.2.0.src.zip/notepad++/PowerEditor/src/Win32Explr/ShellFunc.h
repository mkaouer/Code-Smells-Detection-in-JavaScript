
/*
typedef struct 
{
	   BOOL bRoot;
	   LPITEMIDLIST lpi;
	   LPSHELLFOLDER lpsfParent;
	   LPITEMIDLIST lpifq;
}LPTVITEMDATA;
*/

BOOL GetName (LPSHELLFOLDER lpsf, 
			  LPITEMIDLIST lpi,
		      DWORD dwFlags, 
			  LPSTR lpFriendlyName);
void GetNormalAndSelectedIcons(LPITEMIDLIST lpifq, 
							   LPTV_ITEM lptvitem);
int GetNormalIcon(LPITEMIDLIST lpifq);

int GetIcon (LPITEMIDLIST lpi, 
			 UINT uFlags);
LPITEMIDLIST CopyItemID(LPMALLOC g_pMalloc , 
						LPITEMIDLIST pidl);
LPITEMIDLIST Concatenate(LPMALLOC lpMalloc ,
						 LPCITEMIDLIST pidl1, 
						 LPCITEMIDLIST pidl2);
UINT GetSize(LPCITEMIDLIST pidl);
LPITEMIDLIST GetNextItem(LPCITEMIDLIST pidl);
LPITEMIDLIST Copy(LPMALLOC lpMalloc , 
				  LPCITEMIDLIST pidlSource);
