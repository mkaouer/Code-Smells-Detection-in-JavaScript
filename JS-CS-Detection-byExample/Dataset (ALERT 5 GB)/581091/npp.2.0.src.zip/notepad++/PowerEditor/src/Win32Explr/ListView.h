
#include <shlobj.h>
#include "ShellFunc.h"

HWND hWndListView;
enum SubItems 
{
	SUBITEM_NAME, SUBITEM_TYPE, SUBITEM_SIZE, SUBITEM_MODIFIED
};

HWND	CreateListView (HINSTANCE appInstance, 
						HWND	hParent, 
						HWND hSplitter);		// Parent window handle

BOOL InitListView(HWND hwnd);
BOOL InsertListViewItem(LPSHELLFOLDER lpsf, 
					    LPITEMIDLIST lpi,
					    LPITEMIDLIST lpifq);
void    PopulateList(TV_ITEM tvi);
void onViewStyle(UINT uiStyle, HWND hWndMain);
BOOL ShowPopupStyleMenu(HINSTANCE appInstance);
BOOL ShowStdMenu(LVITEM lvi , BOOL bShowMenu , HINSTANCE appInstance);
BOOL GetSelectedItem(LPNMHDR lpnmh , LV_ITEM* lvItem);
void setDisplayInfo(LV_DISPINFO *lpdi);
void GetTypeOf(LPITEMIDLIST pit, LPSTRRET lpName);

