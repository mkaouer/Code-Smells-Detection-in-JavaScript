#ifndef WEB_CTRL_H
#define WEB_CTRL_H

#include <windows.h>

long EmbedBrowserObject(HWND hwnd);
long DisplayHTMLStr(HWND hwnd, LPCTSTR string);
long DisplayHTMLPage(HWND hwnd, LPTSTR webPageName);
void ResizeBrowser(HWND hwnd, DWORD width, DWORD height);
void UnEmbedBrowserObject(HWND hwnd);
#endif //WEB_CTRL_H
