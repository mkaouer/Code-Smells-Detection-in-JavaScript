//this file is part of notepad++
//Copyright (C)2003 Don HO ( donho@altern.org )
//
//This program is free software; you can redistribute it and/or
//modify it under the terms of the GNU General Public License
//as published by the Free Software Foundation; either
//version 2 of the License, or (at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program; if not, write to the Free Software
//Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

#ifndef FIND_REPLACE_DLG_H
#define FIND_REPLACE_DLG_H

#include "StaticDialog.h"
#include "FindReplaceDlg_rc.h"
#include "Buffer.h"
#include "ScintillaEditView.h"
#include "StatusBar.h"

typedef bool DIALOG_TYPE;
#define REPLACE true
#define FIND false

#define DIR_DOWN true
#define DIR_UP false

#define FIND_REPLACE_STR_MAX 256

const int REPLACE_ALL = 0;
const int MARK_ALL = 1;
const int COUNT_ALL = 2;
const int FIND_ALL = 3;

const int DISPLAY_POS_TOP = 2;
const int DISPLAY_POS_MIDDLE = 1;
const int DISPLAY_POS_BOTTOM = 0;

struct FoundInfo {
	FoundInfo(int start, int end, const char *foundLine, const char *fullPath)
		: _start(start), _end(end), _foundLine(foundLine), _fullPath(fullPath){};
	int _start;
	int _end;
	std::string _foundLine;
	std::string _fullPath;
};

class Finder : public ScintillaEditView {
public:
	Finder() : _markedLine(-1) {};

	void add(FoundInfo fi, int lineNb){
		_foundInfos.push_back(fi);
		std::string str = PathFindFileName(fi._fullPath.c_str());
		str += " (";
		char lnb[16];
		str += itoa(lineNb, lnb, 10);
		str += "):";
		str += fi._foundLine;
		execute(SCI_APPENDTEXT, str.length(), (LPARAM)str.c_str());
	};
	void remove(int index) {
		//_foundInfos.erase();
	};

	void removeAll() {
		_markedLine = -1;
		_foundInfos.clear();
		execute(SCI_CLEARALL);
	};

	FoundInfo & getInfo() {
		int nbInfo = _foundInfos.size();
		int index = getCurrentLineNumber();

		if ((!nbInfo) || (index >= nbInfo))
			throw int(255);
		return _foundInfos[index];
	};

	bool isEmpty() const {
		return _foundInfos.empty();
	};

	int getCurrentMarkedLine() const {return _markedLine;};
	void setCurrentMarkedLine(int line) {_markedLine = line;};

private:
	std::vector<FoundInfo> _foundInfos;
	int _markedLine;
};

struct FindOption {
	bool _isWholeWord;
	bool _isMatchCase;
	bool _isRegExp;
	bool _isWrapAround;
	bool _whichDirection;
	FindOption() :_isWholeWord(true), _isMatchCase(true), _isRegExp(false),\
		_isWrapAround(true), _whichDirection(DIR_DOWN){};
};

class FindReplaceDlg : public StaticDialog
{
public :
	FindReplaceDlg() : StaticDialog(), _pFinder(NULL) {};
	~FindReplaceDlg() {
		if (_pFinder)
		{
			delete _pFinder;
			_statusBar.destroy();
		}
	};

	void init(HINSTANCE hInst, HWND hPere, ScintillaEditView **ppEditView) {
		Window::init(hInst, hPere);
		if (!ppEditView)
			throw int(9900);
		_ppEditView = ppEditView;
	};

	virtual void create(int dialogID);
	
	void initOptionsFromDlg()	{
		_options._isWholeWord = isCheckedOrNot(IDWHOLEWORD);
		_options._isMatchCase = isCheckedOrNot(IDMATCHCASE);
		_options._isRegExp = isCheckedOrNot(IDREGEXP);
		_options._isWrapAround = isCheckedOrNot(IDWRAP);
		_isInSelection = isCheckedOrNot(IDC_IN_SELECTION_CHECK);

		// Set Direction : Down by default
		_options._whichDirection = DIR_DOWN;
		::SendMessage(::GetDlgItem(_hSelf, IDDIRECTIONDOWN), BM_SETCHECK, BST_CHECKED, 0);

		_doPurge = isCheckedOrNot(IDC_PURGE_CHECK);
		_doMarkLine = isCheckedOrNot(IDC_MARKLINE_CHECK);
		_doStyleFoundToken = isCheckedOrNot(IDC_STYLEFOUND_CHECK);

		::EnableWindow(::GetDlgItem(_hSelf, IDCMARKALL), (_doMarkLine || _doStyleFoundToken));
		::SendMessage(::GetDlgItem(_hSelf, IDC_DISPLAYPOS_BOTTOM), BM_SETCHECK, BST_CHECKED, 0);
	};


    void doFindDlg() {
		doDialog(FIND);
	};

	void doReplaceDlg() {
		doDialog(REPLACE);
	};

	void doDialog(DIALOG_TYPE whichType) {
		if (!isCreated())
			create(IDD_FIND_REPLACE_DLG);

		enableReplaceFunc(whichType);
		::SetFocus(::GetDlgItem(_hSelf, IDFINDWHAT));
		display();
	};
	bool processFindNext(const char *txt2find = NULL, FindOption *options = NULL);
	bool processReplace();

	int processAll(int op, bool isEntire = false);
	void replaceAllInOpenedDocs();
	void findAllInOpenedDocs();

	void setSearchText(const char * txt2find) {
		if (!strcmp(txt2find, "")) return;
		HWND handle = ::GetDlgItem(_hSelf, IDFINDWHAT);
		char text[FIND_REPLACE_STR_MAX];
		int count = ::SendMessage(handle, CB_GETCOUNT, 0, 0);
		bool hasFound = false;
		int i = 0;
		for ( ; i < count ; i++)
		{
			::SendMessage(handle, CB_GETLBTEXT, i, (LPARAM)text);
			if (!strcmp(txt2find, text))
			{
				hasFound = true;
				break;
			}
		}
		if (!hasFound)
			i = ::SendMessage(handle, CB_ADDSTRING, 0, (LPARAM)txt2find);
		::SendMessage(handle, CB_SETCURSEL, i, 0);
    };

	void setFinderReadOnly(bool isReadOnly = true) {
		_pFinder->execute(SCI_SETREADONLY, isReadOnly);
	};

	bool isFinderEmpty() const {
		return _pFinder->isEmpty();
	};

	void clearFinder() {
		_pFinder->removeAll();
	};

	void putFindResult(int result) {
		_findAllResult = result;
	};

	/// Sets the direction in which to search.
	/// \param dir Direction to search (DIR_UP or DIR_DOWN)
	///
	void setSearchDirection(bool dir) {
		_options._whichDirection = dir;
	};

protected :
	virtual BOOL CALLBACK run_dlgProc(UINT message, WPARAM wParam, LPARAM lParam);

private :
	DIALOG_TYPE _currentStatus;

	char _text2Find[FIND_REPLACE_STR_MAX];
	char _replaceText[FIND_REPLACE_STR_MAX];
	FindOption _options;

	bool _doPurge;
	bool _doMarkLine;
	bool _doStyleFoundToken;
	bool _isInSelection;

	RECT _replaceCancelPos, _findCancelPos;
	size_t _replaceW, _replaceH, _findW, _findH;

	ScintillaEditView **_ppEditView;
	Finder  *_pFinder;
	StatusBar _statusBar;

	int _findAllResult;

	void enableReplaceFunc(bool isEnable);

	void getSearchTexts() {
		getComboTextFrom(IDFINDWHAT);
	};

	void getReplaceTexts() {
		getComboTextFrom(IDREPLACEWITH);
	};

	void getComboTextFrom(int ID)
	{
		char *str;
		if (ID == IDFINDWHAT) str = _text2Find;
		else if (ID == IDREPLACEWITH) str = _replaceText;
		else return;

		::GetDlgItemText(_hSelf, ID, str, FIND_REPLACE_STR_MAX);
		if (_replaceText[0])
		{
			HWND handle = ::GetDlgItem(_hSelf, ID);
			if (CB_ERR == ::SendMessage(handle, CB_FINDSTRINGEXACT, (WPARAM)-1, (LPARAM)str))
				::SendMessage(handle, CB_ADDSTRING, 0, (LPARAM)str);
		}
	};

	bool isCheckedOrNot(int checkControlID) const {
		return (BST_CHECKED == ::SendMessage(::GetDlgItem(_hSelf, checkControlID), BM_GETCHECK, 0, 0));
	};

	int getDisplayPos() const {
		if (isCheckedOrNot(IDC_DISPLAYPOS_TOP))
			return DISPLAY_POS_TOP;
		else if (isCheckedOrNot(IDC_DISPLAYPOS_MIDDLE))
			return DISPLAY_POS_MIDDLE;
		else //IDC_DISPLAYPOS_BOTTOM
			return DISPLAY_POS_BOTTOM;
	};
	void notify(SCNotification *notification);

	void resizeFinder();
	void resizeStatusBar();
};

#endif //FIND_REPLACE_DLG_H
