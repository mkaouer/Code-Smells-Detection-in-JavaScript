Notepad++ 1.0 beta source note:

To build this package, for this version anyway, you should have Visual Studio .NET to generate the executable file "Notepad++.exe" and visual c++ 6 or Mingw to build Scitilla part. I'm plainning to do a makefile for "Notepad++.exe" and a .vcproj file for the Scitilla part in the next release, so you can choose your prefered compiler.

Mail me to : donho@altern.org if you have any problem/question.