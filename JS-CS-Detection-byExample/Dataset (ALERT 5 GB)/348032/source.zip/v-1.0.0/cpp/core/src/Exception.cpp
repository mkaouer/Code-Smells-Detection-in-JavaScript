/*
 *  Exception.cpp
 *  ZXing
 *
 *  Created by Christian Brunschen on 03/06/2008.
 *  Copyright 2008 ZXing authors All rights reserved.
 *
 */

#include "Exception.h"

