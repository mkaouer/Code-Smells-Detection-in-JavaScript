/*
 * Copyright 2009-2010 L�szl� Bal�zs-Cs�ki
 *
 * This file is part of Pixelitor. Pixelitor is free software: you
 * can redistribute it and/or modify it under the terms of the GNU
 * General Public License, version 3 as published by the Free
 * Software Foundation.
 *
 * Pixelitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Pixelitor.  If not, see <http://www.gnu.org/licenses/>.
 */
package pixelitor.filters.lookup;

import pixelitor.filters.OperationWithParametrizedGUI;
import pixelitor.filters.gui.IntChoiceParam;
import pixelitor.filters.gui.ParamSet;
import pixelitor.filters.gui.RangeParam;
import pixelitor.filters.gui.RangeWithColorsParam;
import pixelitor.filters.levels.RGBLookup;
import pixelitor.utils.ImageUtils;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ShortLookupTable;

/**
 *
 */
public class ColorBalance extends OperationWithParametrizedGUI {
    private static final int CB_MIN = -100;
    private static final int CB_MAX = 100;
    private static final int CB_INIT = 0;

    private static final int EVERYTHING = 0;
    private static final int SHADOWS = 1;
    private static final int MIDTONES = 2;
    private static final int HIGHLIGHTS = 4;

    private static final int LUT_TABLE_SIZE = 256;

    private IntChoiceParam affectParam = new IntChoiceParam("Affect", new IntChoiceParam.Value[]{
            new IntChoiceParam.Value("Everything", EVERYTHING),
            new IntChoiceParam.Value("Shadows", SHADOWS),
            new IntChoiceParam.Value("Midtones", MIDTONES),
            new IntChoiceParam.Value("Highlights", HIGHLIGHTS),
    });

    private RangeParam cyanRedParam = new RangeWithColorsParam(Color.CYAN, Color.RED, "Cyan-Red", CB_MIN, CB_MAX, CB_INIT);
    private RangeParam magentaGreenParam = new RangeWithColorsParam(Color.MAGENTA, Color.GREEN, "Magenta-Green", CB_MIN, CB_MAX,
            CB_INIT);
    private RangeParam yellowBlueParam = new RangeWithColorsParam(Color.YELLOW, Color.BLUE, "Yellow-Blue", CB_MIN, CB_MAX,
            CB_INIT);

    public ColorBalance() {
        super("Color Balance", false);
        paramSet = new ParamSet(
                affectParam,
                cyanRedParam,
                magentaGreenParam,
                yellowBlueParam
        );
    }

    @Override
    public BufferedImage transform(BufferedImage src, BufferedImage dest) {
        short cr = (short) cyanRedParam.getValue();
        short mg = (short) magentaGreenParam.getValue();
        short yb = (short) yellowBlueParam.getValue();

        int affect = affectParam.getValue();

        float[] affectFactor = new float[LUT_TABLE_SIZE];
        for (int i = 0; i < LUT_TABLE_SIZE; i++) {
            switch (affect) {
                case EVERYTHING:
                    affectFactor[i] = 1.0f;
                    break;
                case SHADOWS:
                    affectFactor[i] = 1.0f - (1.0f * i) / LUT_TABLE_SIZE;
                    break;
                case HIGHLIGHTS:
                    affectFactor[i] = (1.0f * i) / LUT_TABLE_SIZE;
                    break;
                case MIDTONES:
                    int halfSize = LUT_TABLE_SIZE / 2;
                    if (i <= halfSize) {
                        affectFactor[i] = (2.0f * i) / LUT_TABLE_SIZE;
                    } else {
                        affectFactor[i] = 2 * (1.0f - (1.0f * i) / LUT_TABLE_SIZE);
                    }
                    break;
            }
        }

        short[] redMapping = new short[LUT_TABLE_SIZE];
        short[] greenMapping = new short[LUT_TABLE_SIZE];
        short[] blueMapping = new short[LUT_TABLE_SIZE];

        if (affect == EVERYTHING) {
            for (short i = 0; i < LUT_TABLE_SIZE; i++) {
                short r = (short) (i + cr - (mg / 2) - (yb / 2));
                r = ImageUtils.limitTo8Bits(r);
                redMapping[i] = r;

                short g = (short) (i + mg - (cr / 2) - (yb / 2));
                g = ImageUtils.limitTo8Bits(g);
                greenMapping[i] = g;

                short b = (short) (i + yb - (mg / 2) - (cr / 2));
                b = ImageUtils.limitTo8Bits(b);
                blueMapping[i] = b;
            }
        } else {
            for (short i = 0; i < LUT_TABLE_SIZE; i++) {
                short r = (short) (i + affectFactor[i] * (cr - (mg / 2) - (yb / 2)));
                r = ImageUtils.limitTo8Bits(r);
                redMapping[i] = r;

                short g = (short) (i + affectFactor[i] * (mg - (cr / 2) - (yb / 2)));
                g = ImageUtils.limitTo8Bits(g);
                greenMapping[i] = g;

                short b = (short) (i + affectFactor[i] * (yb - (mg / 2) - (cr / 2)));
                b = ImageUtils.limitTo8Bits(b);
                blueMapping[i] = b;
            }

        }

        RGBLookup rgbLookup = new RGBLookup(redMapping, greenMapping, blueMapping);
        BufferedImageOp filterOp = new FastLookupOp((ShortLookupTable) rgbLookup.getLookupOp());
        filterOp.filter(src, dest);

        return dest;
    }
}
