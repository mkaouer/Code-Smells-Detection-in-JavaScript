package com.example.butterknife;

public final class R {
  public static final class anim {
    public static int res = 0x7f040000;
  }

  public static final class array {
    public static int res = 0x7f040001;
  }

  public static final class attr {
    public static int res = 0x7f040002;
  }

  public static final class bool {
    public static int res = 0x7f040003;
  }

  public static final class color {
    public static int res = 0x7f040004;
  }

  public static final class dimen {
    public static int res = 0x7f040005;
  }

  public static final class drawable {
    public static int res = 0x7f040006;
  }

  public static final class id {
    public static int res = 0x7f040007;
  }

  public static final class integer {
    public static int res = 0x7f040008;
  }

  public static final class string {
    public static int res = 0x7f040009;
  }
}
