package com.example.butterknife;

public final class R {
  public static final class array {
    public static final int res = 0x7f040001;
  }

  public static final class attr {
    public static final int res = 0x7f040002;
  }

  public static final class bool {
    public static final int res = 0x7f040003;
  }

  public static final class color {
    public static final int res = 0x7f040004;
  }

  public static final class dimen {
    public static final int res = 0x7f040005;
  }

  public static final class drawable {
    public static final int res = 0x7f040006;
  }

  public static final class id {
    public static final int res = 0x7f040007;
  }

  public static final class integer {
    public static final int res = 0x7f040008;
  }

  public static final class string {
    public static final int res = 0x7f040009;
  }
}
