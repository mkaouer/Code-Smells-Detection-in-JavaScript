/// \file variables.cpp
//-----------------------------------------------------------------------------

//#include "util.h"

//Static global variables for speed and security reasons
//See the blowfish constructor for more info
//securely trashed in ~CPasswordSafeApp()

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
