// PwFont.h
//-----------------------------------------------------------------------------

void  SetPasswordFont(CWnd* pDlgItem);
void ReleasePasswordFont();

//-----------------------------------------------------------------------------
// Local variables:
// mode: c++
// End:
