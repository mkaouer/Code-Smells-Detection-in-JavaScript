// ************ Andrew/Oct2004 ************
// really just a list of variables
// used by the ActiveX Help control and the popup method
// All popup text should appear here for easy editing
//
// Modified: 15/06/2005

popFont="Arial,9,,ITALIC"

strPasswordPolicies="A password policy determines how a password is created. The length, letters, numbers, and special characters used to generate a password are easily controlled through the Password Policy dialog in the Option menu."

strBruce="Author of Applied Cryptography and other books, creator of the Blowfish algorithm, and founder and CTO of Counterpane Internet Security."

strSpecialChars="   `   ~   !   @   #   $   %   ^   &   *   (   )   _   +   -   =   |   }   {   [   ]   <   >   ?   /   \   :   ;   |   "

strCombination="In our terminology, the Combination is the password that you use to gain access to the Password Safe database."

strPopText1="Dummy Placeholder"

strExternalFile="Supported file formats: Version 1.x Password Safe database; tab-delimited text (.txt) files. It is STRONGLY recommended that the use of text files with sensitive password information be avoided when possible and that the file be securely deleted or wiped afterwards."

strHexDec="Only the following:\n 0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f"
