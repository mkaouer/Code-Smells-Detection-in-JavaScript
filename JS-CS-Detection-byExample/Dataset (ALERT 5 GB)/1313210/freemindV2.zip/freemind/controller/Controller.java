/*FreeMind - A Program for creating and viewing Mindmaps
 *Copyright (C) 2000  Joerg Mueller <joergmueller@bigfoot.com>
 *See COPYING for Details
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package freemind.controller;

import freemind.main.FreeMind;
import freemind.main.Tools;
import freemind.view.mindmapview.MapView;
import freemind.view.mindmapview.NodeView;
import freemind.model.MindMap;
import freemind.model.MindMapNode;
import freemind.model.simplemodel.NodeModel;
import freemind.model.simplemodel.MapModel;
import java.io.File;
import java.net.URL;
import java.net.MalformedURLException;
import java.util.List;
import java.util.ListIterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;
import java.awt.Component;
import java.awt.Color;
import java.awt.Point;
import java.awt.print.PrinterJob;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import javax.swing.JOptionPane;
import javax.swing.JColorChooser;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileFilter;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.AbstractAction;
import javax.swing.Action;

/**
 * Provides the methods to edit/change a Node.
 * Forwards all messages to MapModel(editing) or MapView(navigation).
 */
public class Controller {

    private Map views = new TreeMap();
    private MapView view;
    private FreeMind frame;
    private PopupMenu popupMenu;
    private NodeMouseListener nodeMouseListener;
    private NodeKeyListener nodeKeyListener;

    Action newMap = new NewMapAction(this);
    Action open = new OpenAction(this);
    Action close = new CloseAction();
    Action save = new SaveAction(this);
    Action saveAs = new SaveAsAction(this);
    Action print = new PrintAction();
    public Action quit = new QuitAction(this);
    Action background = new BackgroundAction();
    Action about = new AboutAction();
    Action lastMap = new LastMapAction(this);
    Action nextMap = new NextMapAction(this);
    Action cut = new CutAction(this);
    Action paste = new PasteAction(this);
    Action setLink = new SetLinkAction();
    Action followLink = new FollowLinkAction();
    Action fork = new ForkAction();
    Action bubble = new BubbleAction();
    Action nodeColor = new NodeColorAction();
    Action edgeColor = new EdgeColorAction();
    Action linear = new LinearAction();
    Action bezier = new BezierAction();
    Action italic = new ItalicAction(this);
    Action bold = new BoldAction(this);
    Action underline = new UnderlineAction(this);
    Action normalFont = new NormalFontAction(this);

    //
    // Constructors
    //

    public Controller() {
	//Create the Popup Menu
	popupMenu = new PopupMenu(this);
  	nodeMouseListener = new NodeMouseListener(this);
	nodeKeyListener = new NodeKeyListener(this);
	setAllActions(false);
    }

    //
    // get/set methods
    //

    Map getViews() {
	return views;
    }

    public MapView getView() {
	return view;
    }

    public NodeKeyListener getNodeKeyListener() {
	return nodeKeyListener;
    }

    public NodeMouseListener getNodeMouseListener() {
	return nodeMouseListener;
    }

    public void setFrame(FreeMind frame) {
	this.frame = frame;
    }


    //
    // Node Navigation
    //

    void moveUp() {
	getView().moveUp();
    }

    void moveDown() {
	getView().moveDown();
    }

    void moveLeft() {
	getView().moveLeft();
    }

    void moveRight() {
	getView().moveRight();
    }

    void moveToRoot() {
	getView().moveToRoot();
    }

    void select( NodeView node ) {
	getView().select(node);
    }

    void centerNode() {
	getView().centerNode(getView().getSelected());
    }

    //
    //  Node Editing
    //

    void addNew(NodeView parent) {
	NodeModel newNode = new NodeModel(FreeMind.getResources().getString("new_node"));
	getModel().insertNodeInto(newNode,parent.getModel(), 0 );
	edit(newNode.getViewer(),parent);
    }

    void delete(NodeView node) {
	if (!node.isRoot()) {
	    getModel().removeNodeFromParent(node.getModel());
	}
    }

    void edit() {
	if (getView().getSelected() != null) {
	    edit(getView().getSelected());
	}
    }

    void edit(final NodeView node) {
	edit(node,node);
    }

    void setFontSize(int fontSize) {
	getModel().setFontSize(getView().getSelected().getModel(),fontSize);
    }

    void setFont(String font) {
	getModel().setFont(getView().getSelected().getModel(),font);
    }

    void setLink() {
	URL link;
	File input;
	JFileChooser chooser = new JFileChooser();
	chooser.addChoosableFileFilter(new MindMapFilter());
	int returnVal = chooser.showOpenDialog(getView());
	if (returnVal==JFileChooser.APPROVE_OPTION) {
	    input = chooser.getSelectedFile();
	    try {
		link = input.toURL();
	    } catch (MalformedURLException ex) {
		JOptionPane.showMessageDialog(frame,"couldn't create valid URL!");
		return;
	    }
	    getModel().setLink(getView().getSelected().getModel(),link);
	    getModel().setBold(getView().getSelected().getModel());
	}
    }

    //
    // Map Navigation
    //

    void changeToMap(String map) {
	setView( (MapView)(getViews().get(map)) );
	viewChanged();
    }

    void loadURL() {
	MindMapNode node = getView().getSelected().getModel();
	URL link = node.getLink();
	if (link != null) {
	    loadURL(link);
	}
    }

    void nextMap() {
	List keys = new LinkedList(getViews().keySet());
	int index = keys.indexOf(getView().toString());
	ListIterator i = keys.listIterator(index+1);
	if (i.hasNext()) {
	    changeToMap((String)i.next());
	}
	updateNavigationActions();
    }

    void previousMap() {
	List keys = new LinkedList(getViews().keySet());
	int index = keys.indexOf(getView().toString());
	ListIterator i = keys.listIterator(index);
	if (i.hasPrevious()) {
	    changeToMap((String)i.previous());
	}
	updateNavigationActions();
    }

    //
    // load&save
    //

    void saveXML(File file) {
	getModel().saveXML(file);
    }

    void loadXML(File file) {
	MindMap model = new MapModel();
	model.loadXML(file);
	setView( new MapView( model,this ) );
	getView().init();
	addToViews(getView().toString(), getView());
    }

    //
    // other
    //

    void showPopupMenu(Component c, int x, int y) {
	popupMenu.show(c,x,y);
    }

    void setZoom(float zoom) {
	getView().setZoom(zoom);
    }




    //////////////
    // Private methods. Internal implementation
    ////////////




    //
    // get/set Methods
    //

    private void setView(MapView view) {
	this.view = view;
	frame.setView(view);
    }

    private FreeMind getFrame() {
	return frame;
    }

    /**Returns the current model*/
    private MindMap getModel() {
	return getView().getModel();
    }

    //
    // Node editing
    //

    private void edit(final NodeView node,final NodeView toBeSelected) {
	getView().scrollNodeToVisible(node);
	final JTextField input = new JTextField(node.getModel().toString());
	Point loc = node.getLocation();
	Point scroll = ((JViewport)getView().getParent()).getViewPosition();
	Point content = frame.getContentPane().getLocation();
	//Todo: Remove the constant(40) (the menubar) from this calc
	input.setBounds(loc.x-scroll.x+content.x,loc.y-scroll.y+content.y+40,input.getPreferredSize().width,15);
	input.selectAll();
	input.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		    getView().select(toBeSelected);
		    //Focus is lost, so focusLost() is called, which does the work
		}
	    });
	input.addFocusListener(new FocusAdapter() {
		public void focusLost(FocusEvent e) {
  		    getModel().changeNode(node.getModel(),input.getText());
  		    frame.getLayeredPane().remove(input);
		}
	    });
		
	frame.getLayeredPane().add(input,2000);
	input.requestFocus();
	frame.repaint();
    }

    private void getFocus() {
	getView().getSelected().requestFocus();
    }

    //
    // Multiple Views management
    //
    
    private void viewChanged() {
	frame.updateMenuBar();//to show the new map in the mindmaps menu
	updateNavigationActions();
	if (getView() == null) {
	    getFrame().setTitle("FreeMind");
	} else {
	    getFrame().setTitle("FreeMind - " + getView().toString());
	}
    }

    private void addToViews(String key, MapView value) {
	views.put(key,value);
	viewChanged();
	setAllActions(true);
    }

    private void removeFromViews(String key) {
	views.remove(key);
	viewChanged();
	if(getViews().isEmpty()) {
	    setAllActions(false);
	}
    }

    private void loadURL(URL url) {
	String fileName = url.getFile();
	File file = new File(fileName);
	loadXML(file);
    }

    //
    // Actions management
    //

    /**
     * Manage the availabilty of all Actions dependend 
     * of whether there is a map or not
     */
    private void setAllActions(boolean enabled) {
	background.setEnabled(enabled);
	fork.setEnabled(enabled);
	bubble.setEnabled(enabled);
	nodeColor.setEnabled(enabled);
	edgeColor.setEnabled(enabled);
	linear.setEnabled(enabled);
	bezier.setEnabled(enabled);
	italic.setEnabled(enabled);
	bold.setEnabled(enabled);
	underline.setEnabled(enabled);
	normalFont.setEnabled(enabled);
	print.setEnabled(enabled);
	setLink.setEnabled(enabled);
	followLink.setEnabled(enabled);
	cut.setEnabled(enabled);
	save.setEnabled(enabled);
	saveAs.setEnabled(enabled);
	close.setEnabled(enabled);
    }

    private void updateNavigationActions() {
	List keys = new LinkedList(getViews().keySet());
	if (getView() == null) {
	    return;
	}
	int index = keys.indexOf(getView().toString());
	ListIterator i = keys.listIterator(index);
	if (i.hasPrevious()) {
	    lastMap.setEnabled(true);
	} else {
	    lastMap.setEnabled(false);
	}
	if (i.hasNext()) {
	    i.next();
	    if (i.hasNext()) {
		nextMap.setEnabled(true);
	    } else {
		nextMap.setEnabled(false);
	    }
	}
    }




    //////////////
    // Inner Classes
    ////////////


    //
    // program/map control
    //

    private class QuitAction extends AbstractAction {
	QuitAction(Controller controller) {
	    super(FreeMind.getResources().getString("quit"));
	}
	public void actionPerformed(ActionEvent e) {
	    while (getView() != null) {
		close.actionPerformed(e);
	    }
	    System.exit(0);
	}
    }

    /**This closes only the current map*/
    private class CloseAction extends AbstractAction {
	String[] options = {FreeMind.getResources().getString("yes"),FreeMind.getResources().getString("no"),FreeMind.getResources().getString("cancel")};
	CloseAction() {
	    super(FreeMind.getResources().getString("close"));
	}
	public void actionPerformed(ActionEvent e) {
	    if (!getModel().isSaved()) {
		String text =FreeMind.getResources().getString("save_unsaved")+"\n"+view.toString();
		String title = FreeMind.getResources().getString("save");
		int returnVal = JOptionPane.showOptionDialog( getView(),text,title,JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.QUESTION_MESSAGE,null,options,options[0]);
		if (returnVal==JOptionPane.YES_OPTION) {
		    save.actionPerformed(e);
		} else if (returnVal==JOptionPane.NO_OPTION) {
		} else if (returnVal==JOptionPane.CANCEL_OPTION) {
		    //How should I do this? quitAction must be notified, but if I throw an Exception,
		    // i can't catch it (its an action)
		    System.err.println("I'm sorry, cancel is currently not supported.");
		}
	    }
	    String toBeClosed = getView().toString();
	    changeToAnotherMap(toBeClosed);
	    removeFromViews(toBeClosed);
	}

	private void changeToAnotherMap(String toBeClosed) {
	    List keys = new LinkedList(getViews().keySet());
	    int index = keys.indexOf(getView().toString());
	    for (ListIterator i = keys.listIterator(); i.hasNext();) {
		String key = (String)i.next();
		if (!key.equals(toBeClosed)) {
		    changeToMap(key);
		    return;
		}
	    }
	    //What to do if no other maps are available?
	    setView(null);
	}
    }

    private class NewMapAction extends AbstractAction {
	Controller c;
	NewMapAction(Controller controller) {
	    super(FreeMind.getResources().getString("new"), new ImageIcon(controller.getClass().getResource("/images/New24.gif")));
	    c = controller;
	    //Workaround to get the images loaded in jar file.
	    //they have to be added to jar manually with full path from root
	    //I really don't like this, but it's a bug of java
	}
	public void actionPerformed(ActionEvent e) {
	    MindMap model = new MapModel();
	    setView( new MapView( model,c ) );
	    getView().init();
	    addToViews(getView().toString(), getView());
	}
    }

    private class OpenAction extends AbstractAction {
	OpenAction(Object controller) {
	    super(FreeMind.getResources().getString("open"), new ImageIcon(controller.getClass().getResource("/images/Open24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    JFileChooser chooser = new JFileChooser();
	    //chooser.setLocale(currentLocale);
	    chooser.addChoosableFileFilter(new MindMapFilter());
	    int returnVal = chooser.showOpenDialog(getView());
	    if (returnVal==JFileChooser.APPROVE_OPTION) {
		loadXML(chooser.getSelectedFile());
	    }
	}
    }

    private class SaveAction extends AbstractAction {
	SaveAction(Object controller) {
	    super(FreeMind.getResources().getString("save"), new ImageIcon(controller.getClass().getResource("/images/Save24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    if (getModel().isSaved()) return;
	    if (getModel().getFile()==null) {
		saveAs.actionPerformed(e);
	    } else {
		saveXML(getModel().getFile());
	    }
	}
    }	    

    private class SaveAsAction extends AbstractAction {
	SaveAsAction(Object controller) {
	    super(FreeMind.getResources().getString("save_as"), new ImageIcon(controller.getClass().getResource("/images/SaveAs24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    JFileChooser chooser = new JFileChooser();
	    //chooser.setLocale(currentLocale);
	    chooser.addChoosableFileFilter(new MindMapFilter());
	    int returnVal = chooser.showSaveDialog(getView());
	    if (returnVal==JFileChooser.APPROVE_OPTION) {//ok pressed
		File f = chooser.getSelectedFile();
		//Force the extension to be .mm
		String ext = Tools.getExtension(f);
		if(!ext.equals("mm")) {
		    f = new File(f.getParent(),f.getName()+".mm");
		}
		saveXML(f);
		//Update the name of the map
		getViews().remove(getView().toString());//removeFromViews() doesn't work because viewChanged()
		//must not be called at this state
		getView().rename();
		addToViews(getView().toString(),getView());
	    }
	}
    }

    private class PrintAction extends AbstractAction {
	PrintAction() {
	    super(FreeMind.getResources().getString("print"));
	    setEnabled(false);
	}
	public void actionPerformed(ActionEvent e) {
	    PrinterJob printJob = PrinterJob.getPrinterJob();
	    printJob.setPrintable(getView());
	    if (printJob.printDialog()) {
		try {
		    printJob.print();
		} catch (Exception ex) {
		    ex.printStackTrace();
		}
	    }
	}
    }

    private class AboutAction extends AbstractAction {
	AboutAction() {
	    super(FreeMind.getResources().getString("about"));
	}
	public void actionPerformed(ActionEvent e) {
	    JOptionPane.showMessageDialog(getView(),FreeMind.getResources().getString("about_text")+FreeMind.version);
	}
    }

    //
    // Map navigation
    //

    private class LastMapAction extends AbstractAction {
	LastMapAction(Controller controller) {
	    super("Last Map", new ImageIcon(controller.getClass().getResource("/images/Back24.gif")));
	    setEnabled(false);
	}
	public void actionPerformed(ActionEvent event) {
	    previousMap();
	}
    }

    private class NextMapAction extends AbstractAction {
	NextMapAction(Controller controller) {
	    super("Next Map", new ImageIcon(controller.getClass().getResource("/images/Forward24.gif")));
	    setEnabled(false);
	}
	public void actionPerformed(ActionEvent event) {
	    nextMap();
	}
    }

    private class FollowLinkAction extends AbstractAction {
	FollowLinkAction() {
	    super(FreeMind.getResources().getString("follow_link"));
	}
	public void actionPerformed(ActionEvent e) {
	    loadURL();
	}
    }

    //
    // Preferences
    //

    private class BackgroundAction extends AbstractAction {
	BackgroundAction() {
	    super(FreeMind.getResources().getString("background"));
	}
	public void actionPerformed(ActionEvent e) {
	    Color color = JColorChooser.showDialog(getView(),"Choose Background Color:",getView().getBackground() );
	    getModel().setBackgroundColor(color);
	}
    }

    //
    // Node editing
    //

    private class CutAction extends AbstractAction {
	CutAction(Object controller) {
	    super(FreeMind.getResources().getString("cut"), new ImageIcon(controller.getClass().getResource("/images/Cut24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    MindMapNode node = getView().getSelected().getModel();
	    if (node.isRoot()) return;
	    paste.setEnabled(true);
	    getModel().cut(node);
	}
    }

    private class PasteAction extends AbstractAction {
	PasteAction(Object controller) {
	    super(FreeMind.getResources().getString("paste"),new ImageIcon(controller.getClass().getResource("/images/Paste24.gif")));
	    setEnabled(false);
	}
	public void actionPerformed(ActionEvent e) {
	    setEnabled(false);
	    getModel().paste(getView().getSelected().getModel());
	}
    }

    private class SetLinkAction extends AbstractAction {
	SetLinkAction() {
	    super(FreeMind.getResources().getString("set_link"));
	}
	public void actionPerformed(ActionEvent e) {
	    setLink();
	}
    }

    private class ForkAction extends AbstractAction {
	ForkAction() {
	    super(FreeMind.getResources().getString("fork"));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setNodeStyle(getView().getSelected().getModel(), "fork");
	}
    }

    private class BubbleAction extends AbstractAction {
	BubbleAction() {
	    super(FreeMind.getResources().getString("bubble"));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setNodeStyle(getView().getSelected().getModel(), "bubble");
	}
    }

    private class LinearAction extends AbstractAction {
	LinearAction() {
	    super(FreeMind.getResources().getString("linear"));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setEdgeStyle(getView().getSelected().getModel(), "linear");
	}
    }

    private class BezierAction extends AbstractAction {
	BezierAction() {
	    super(FreeMind.getResources().getString("bezier"));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setEdgeStyle(getView().getSelected().getModel(), "bezier");
	}
    }

    //
    // Fonts
    //

    private class ItalicAction extends AbstractAction {
	ItalicAction(Object controller) {
	    super(FreeMind.getResources().getString("italic"), new ImageIcon(controller.getClass().getResource("/images/Italic24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setItalic(getView().getSelected().getModel());
	}
    }

    private class BoldAction extends AbstractAction {
	BoldAction(Object controller) {
	    super(FreeMind.getResources().getString("bold"), new ImageIcon(controller.getClass().getResource("/images/Bold24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setBold(getView().getSelected().getModel());
	}
    }

    private class NormalFontAction extends AbstractAction {
	NormalFontAction(Object controller) {
	    super(FreeMind.getResources().getString("normal"), new ImageIcon(controller.getClass().getResource("/images/Normal24.gif")));	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setNormalFont(getView().getSelected().getModel());
	}
    }

    /**Not yet implemented*/
    private class UnderlineAction extends AbstractAction {
	UnderlineAction(Object controller) {
	    super(FreeMind.getResources().getString("underline"), new ImageIcon(controller.getClass().getResource("/images/Underline24.gif")));
	}
	public void actionPerformed(ActionEvent e) {
	    getModel().setUnderlined(getView().getSelected().getModel());
	}
    }

    //
    // Color
    //

    private class NodeColorAction extends AbstractAction {
	NodeColorAction() {
	    super(FreeMind.getResources().getString("node_color"));
	}
	public void actionPerformed(ActionEvent e) {
	    Color color = JColorChooser.showDialog(getView(),"Choose Node Color:",getModel().getNodeColor(getView().getSelected().getModel()) );
	    getModel().setNodeColor(getView().getSelected().getModel(), color);
	}
    }

    private class EdgeColorAction extends AbstractAction {
	EdgeColorAction() {
	    super(FreeMind.getResources().getString("edge_color"));
	}
	public void actionPerformed(ActionEvent e) {
	    MindMapNode node = getView().getSelected().getModel();
	    Color color = JColorChooser.showDialog(getView(),"Choose Edge Color:",getModel().getEdgeColor(node));
	    getModel().setEdgeColor(node,color);
	}
    }

    //
    // Other Classes
    //

    private class MindMapFilter extends FileFilter {
	public boolean accept(File f) {
	    if (f.isDirectory()) return true;
	    String extension = Tools.getExtension(f);
	    if (extension != null) {
		if (extension.equals("mm")) {
		    return true;
		} else {
		    return false;
		}
	    }
	    return false;
	}
	
	public String getDescription() {
	    return FreeMind.getResources().getString("mindmaps");
	}
    }
}//Class Controller
