/*FreeMind - A Program for creating and viewing Mindmaps
 *Copyright (C) 2000  Joerg Mueller <joergmueller@bigfoot.com>
 *See COPYING for Details
 *
 *This program is free software; you can redistribute it and/or
 *modify it under the terms of the GNU General Public License
 *as published by the Free Software Foundation; either version 2
 *of the License, or (at your option) any later version.
 *
 *This program is distributed in the hope that it will be useful,
 *but WITHOUT ANY WARRANTY; without even the implied warranty of
 *MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *GNU General Public License for more details.
 *
 *You should have received a copy of the GNU General Public License
 *along with this program; if not, write to the Free Software
 *Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package freemind.model.simplemodel;

import freemind.main.FreeMind;
import freemind.model.MindMapNode;
import freemind.model.MindMapEdge;
import freemind.main.Tools;
import java.awt.Color;

import  org.w3c.dom.Document;
import org.w3c.dom.Element;


public class EdgeModel implements MindMapEdge {

    private MindMapNode source, target;
    private Color color; 
    private String style;

    //
    // Constructors
    //

    public EdgeModel(MindMapNode source, MindMapNode target) {
	setSource(source);
	setTarget(target);
    }

    public EdgeModel(MindMapNode source, MindMapNode target, String style, Color color) {
	this(source,target);
	setStyle(style);
	setColor(color);
    }

    //
    // Interface MindMapEdge
    //

    public void saveXML(Document doc, Element xmlParent) {
	Element edge = doc.createElement("edge");
	xmlParent.appendChild(edge);
	if (style!=null) edge.setAttribute("style",style);
	if (color!=null) edge.setAttribute("color",Tools.colorToXml(this.color));
    }

    public void loadXML(Element edge) {
	if (!edge.getAttribute("style").equals("")) {
	    setStyle(edge.getAttribute("style"));
	}
	if (!edge.getAttribute("color").equals("")) {
	    setColor(Tools.xmlToColor(edge.getAttribute("color") ) );
	}
    }

    public MindMapNode getSource() {
	return source;
    }

    public void setSource(MindMapNode source) {
	this.source = source;
    }

    public MindMapNode getTarget() {
	return target;
    }

    public void setTarget(MindMapNode target) {
	this.target = target;
    }

    public Color getColor() {
	if(color==null) {
	    if (getSource().isRoot()) {
		String stdcolor = FreeMind.userProps.getProperty("standardedgecolor");
		if (stdcolor.length() == 7) {
		    return Tools.xmlToColor(stdcolor);
		}
		return Color.blue;
	    }
	    return getSource().getEdge().getColor();
	}
	return color;
    }

    public void setColor(Color color) {
	this.color = color;
    }

    public String getStyle() {
	if(style==null) {
	    if (getSource().isRoot()) {
		return FreeMind.userProps.getProperty("standardedgestyle");
	    }
	    return getSource().getEdge().getStyle();
	}
	return style;
    }

    public void setStyle(String style) {
	this.style = style;
    }
}
