#!/bin/sh
java -jar freemind.jar