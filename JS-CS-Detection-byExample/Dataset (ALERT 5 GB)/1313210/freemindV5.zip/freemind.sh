#!/bin/sh
java -jar ./lib/freemind.jar