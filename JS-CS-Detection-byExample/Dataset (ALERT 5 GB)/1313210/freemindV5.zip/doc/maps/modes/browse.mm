<map>
    <node LINK="../tutorial.mm" TEXT="Browse">
        <font NAME="Lucida Sans Regular" SIZE="16"/>
    </node>
</map>
