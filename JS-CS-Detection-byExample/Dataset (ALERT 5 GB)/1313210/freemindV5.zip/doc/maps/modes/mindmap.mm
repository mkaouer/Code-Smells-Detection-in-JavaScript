<map>
    <node LINK="../tutorial.mm" TEXT="MindMap Mode">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
        <node TEXT="Overview">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
            <node TEXT="Currently the most important mode in FreeMind">
                <font NAME="Lucida Sans Regular" SIZE="12"/>
            </node>
            <node TEXT="To create MindMaps (.mm files)">
                <font NAME="Lucida Sans Regular" SIZE="12"/>
            </node>
            <node TEXT="MindMapping and MindMap authoring tool">
                <font NAME="Lucida Sans Regular" SIZE="12"/>
            </node>
        </node>
        <node TEXT="Usage">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
            <node TEXT="Step-By-Step">
                <font NAME="Lucida Sans Regular" SIZE="12"/>
                <node TEXT="1: Start the FreeMind application">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="2: Select &quot;MindMap&quot; from the Modes menu">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="3: Select &quot;New&quot; from the File menu">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="4: Select the root node">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="5: Press Enter">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="6: Type some text into the root node">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="7: Press Enter again">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="8: Click with your right mouse key on the root node">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                    <node TEXT="A menu Pops up">
                        <font NAME="Lucida Sans Regular" SIZE="12"/>
                    </node>
                </node>
                <node TEXT="9: Select &quot;New Node&quot; from the Popup window">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="10: Type some Text into the new node">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
                <node TEXT="Congratulations! You have created your first MindMap.">
                    <font NAME="Lucida Sans Regular" SIZE="12"/>
                </node>
            </node>
        </node>
    </node>
</map>
