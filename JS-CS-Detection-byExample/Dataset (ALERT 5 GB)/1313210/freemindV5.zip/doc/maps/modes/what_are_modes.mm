<map>
    <node LINK="file:/home/joerg/cvs/freemind/doc/maps/tutorial.mm" TEXT="What are modes?">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
    </node>
</map>
