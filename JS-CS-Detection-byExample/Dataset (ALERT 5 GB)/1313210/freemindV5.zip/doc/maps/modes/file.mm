<map>
    <node LINK="../tutorial.mm" TEXT="The File Mode">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
        <node TEXT="To edit and browse your filesystem and to call programs">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
        <node TEXT="This mode is not ready yet, so I have disabled it by default">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
    </node>
</map>
