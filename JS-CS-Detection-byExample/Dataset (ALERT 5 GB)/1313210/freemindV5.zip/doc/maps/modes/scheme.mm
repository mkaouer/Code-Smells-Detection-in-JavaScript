<map>
    <node LINK="../tutorial.mm" TEXT="Scheme Mode">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
        <node TEXT="To edit Scheme and Lisp programs">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
        <node TEXT="This mode is not ready yet so I&apos;ve disabled it by default">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
    </node>
</map>
