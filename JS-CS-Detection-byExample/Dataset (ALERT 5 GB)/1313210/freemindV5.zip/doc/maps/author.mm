<map>
    <node LINK="freemind.mm" COLOR="#000099" TEXT="The Author">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
        <node TEXT="Joerg Mueller">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
        <node TEXT="University of Freiburg, Germany">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
        <node TEXT="email: joergmueller@bigfoot.com">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
    </node>
</map>
