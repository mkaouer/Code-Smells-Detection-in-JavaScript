<map>
    <node TEXT="FreeMind">
        <font NAME="Lucida Sans Regular" BOLD="true" SIZE="18"/>
        <node LINK="author.mm" TEXT="The Author">
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
        <node LINK="tutorial.mm" COLOR="#cc0000" TEXT="Tutorial">
            <font NAME="Lucida Sans Regular" SIZE="24"/>
        </node>
        <node LINK="project/project.mm" COLOR="#990099" TEXT="The Project">
            <font NAME="Lucida Sans Regular" SIZE="14"/>
        </node>
        <node LINK="http://freemind.sourceforge.net" COLOR="#009999" TEXT="The Website" STYLE="bubble">
            <edge COLOR="#009999"/>
            <font NAME="Lucida Sans Regular" SIZE="12"/>
        </node>
    </node>
</map>
