<map>
    <node LINK="../freemind.mm" TEXT="The FreeMind Project">
        <font NAME="Lucida Sans Regular" SIZE="12"/>
    </node>
</map>
