document.getElementById("color").focus();$(document).keydown(function(evt){if(evt.keyCode==13){$("body").css("background-color",$("#color").val())}});
//@ sourceMappingURL=script.uglify.js.map