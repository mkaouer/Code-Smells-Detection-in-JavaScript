exports.test = function() {
  return "module1";
}
