var sampleFunction;

(function()
{
	var privateVar = 'private';
	
	sampleFunction = function()
	{
		return privateVar+'67868';
	};
})();
