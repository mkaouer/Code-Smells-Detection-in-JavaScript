$(document).ready(function()
{
	$('#content').html(sampleFunction()); 
});