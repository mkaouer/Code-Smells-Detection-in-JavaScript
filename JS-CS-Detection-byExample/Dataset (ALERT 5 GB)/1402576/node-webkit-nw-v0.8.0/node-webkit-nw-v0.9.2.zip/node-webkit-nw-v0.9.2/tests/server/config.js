exports.Expires = {
    fileMatch: /^(.gif|.png|.jpg|.js|.css)$/ig,
    maxAge: 606024365
};
