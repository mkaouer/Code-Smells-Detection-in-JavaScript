Pixelitor as a whole is licensed under the GNU GPL version 3.

Various third party libraries are licensed under GPL-compatible licenses, for example the JHLabs.com filters library uses the Apache 2.0 license. See the individual source file headers for details. 

The following libraries are used:

- SwingX (http://swinglabs.org/)
- JH Labs image filters (http://www.jhlabs.com/ and also available as an open-source project at: https://pixels.dev.java.net/)

