/*
 * Copyright 2010 L�szl� Bal�zs-Cs�ki
 *
 * This file is part of Pixelitor. Pixelitor is free software: you
 * can redistribute it and/or modify it under the terms of the GNU
 * General Public License, version 3 as published by the Free
 * Software Foundation.
 *
 * Pixelitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Pixelitor.  If not, see <http://www.gnu.org/licenses/>.
 */
package pixelitor.operations.gui;

import org.jdesktop.swingx.graphics.GraphicsUtilities;
import pixelitor.AppLogic;

import javax.swing.*;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

/**
 *
 */
public class ImagePositionSelector extends JComponent implements MouseMotionListener, MouseListener {
    private ImagePositionPanel imagePositionPanel;
    private ImagePositionParam model;
    private BufferedImage thumb;

    public ImagePositionSelector(ImagePositionPanel imagePositionPanel, ImagePositionParam model, int size) {
        this.imagePositionPanel = imagePositionPanel;
        this.model = model;
        addMouseListener(this);
        addMouseMotionListener(this);

        BufferedImage actualImage = AppLogic.getActiveLayerImage();
        thumb = GraphicsUtilities.createThumbnailFast(actualImage, size);

        setPreferredSize(new Dimension(thumb.getWidth(), thumb.getHeight()));
    }

    @Override
    public void paintComponent(Graphics g) {

        int totalWidth = thumb.getWidth();
        int totalHeight = thumb.getHeight();

        g.drawImage(thumb, 0, 0, null);

        Graphics2D g2 = (Graphics2D) g;
        int currentX = (int) (model.getRelativeX() * totalWidth);
        int currentY = (int) (model.getRelativeY() * totalHeight);
        int controlSize = 5;


        // lines
        g.setColor(Color.BLACK);
        g.drawLine(currentX + 1, 0, currentX + 1, totalHeight - 1); // west
        g.drawLine(currentX - 1, 0, currentX - 1, totalHeight - 1); // east

        if (currentY <= totalHeight) {
            Line2D.Float horizontalLineNorth = new Line2D.Float(0, currentY - 1, totalWidth, currentY - 1);
            Line2D.Float horizontalLineSouth = new Line2D.Float(0, currentY + 1, totalWidth, currentY + 1);
            g2.draw(horizontalLineNorth);
            g2.draw(horizontalLineSouth);
        }

        g.setColor(Color.WHITE);
        Line2D.Float verticalLine = new Line2D.Float(currentX, 0, currentX, totalHeight);
        g2.draw(verticalLine);
        if (currentY <= totalHeight) {
            Line2D.Float horizontalLine = new Line2D.Float(0, currentY, totalWidth, currentY);
            g2.draw(horizontalLine);
        }

        // rectangle in the middle
        g.setColor(Color.BLACK);
        g2.draw(new Rectangle2D.Float(currentX - controlSize, currentY - controlSize, controlSize * 2, controlSize * 2));
        g.setColor(Color.WHITE);
        g2.fill(new Rectangle2D.Float(currentX - controlSize + 1, currentY - controlSize + 1, controlSize * 2 - 1, controlSize * 2 - 1));
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        moveControl(e);
    }

    private void moveControl(MouseEvent e) {
        int mouseX = e.getX();
        int mouseY = e.getY();

        float relativeX = ((float) mouseX) / thumb.getWidth();
        float relativeY = ((float) mouseY) / thumb.getHeight();
        model.setRelativeX(relativeX);
        model.setRelativeY(relativeY);

        imagePositionPanel.updateSlidersFromModel();

        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        moveControl(e);
        ParamAdjustingListener listener = model.getAdjustingListener();
        if (listener != null) {
            listener.paramAdjusted();
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

}
