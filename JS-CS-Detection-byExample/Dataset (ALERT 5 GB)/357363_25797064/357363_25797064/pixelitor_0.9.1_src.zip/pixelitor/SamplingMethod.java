package pixelitor;

/**
 *
 */
public enum SamplingMethod {
    SAMPLE1, SAMPLE9
}
