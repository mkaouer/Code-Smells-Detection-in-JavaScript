Pixelitor as a whole is licensed under the GNU GPL version 3:
http://www.gnu.org/licenses/gpl-3.0.html

Various third party libraries are licensed under GPL-compatible licenses:

- The JHLabs.com image filters library (http://www.jhlabs.com/ and also available as an open-source project at https://pixels.dev.java.net/) uses the Apache 2.0 license: 
http://www.apache.org/licenses/LICENSE-2.0

- SwingX (https://swingx.dev.java.net/) is licensed under the GNU Lesser General Public License: 
http://www.gnu.org/copyleft/lesser.html

Also see the individual source file headers. 
