package pixelitor.utils;

/**
 *
 */
public enum SamplingMethod {
    SAMPLE1, SAMPLE9
}
