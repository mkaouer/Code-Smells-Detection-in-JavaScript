Pixelitor as a whole is licensed under the GNU GPL version 3.

Various third party libraries are licensed under GPL-compatible licenses, for example the JHLabs.com filters library uses the Apache 2.0 license. See the individual source file headers for details
