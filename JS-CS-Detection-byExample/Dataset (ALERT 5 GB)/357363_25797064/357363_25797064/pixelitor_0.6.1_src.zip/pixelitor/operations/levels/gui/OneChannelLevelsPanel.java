/*
 * Copyright 2009-2010 L�szl� Bal�zs-Cs�ki
 *
 * This file is part of Pixelitor. Pixelitor is free software: you
 * can redistribute it and/or modify it under the terms of the GNU
 * General Public License, version 3 as published by the Free
 * Software Foundation.
 *
 * Pixelitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Pixelitor.  If not, see <http://www.gnu.org/licenses/>.
 */

package pixelitor.operations.levels.gui;

import pixelitor.operations.levels.GrayScaleLookup;
import pixelitor.operations.gui.ParamAdjustingListener;
import pixelitor.operations.gui.RangeParam;
import pixelitor.utils.SliderSpinner;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Collection;
import java.awt.Color;

public class OneChannelLevelsPanel extends JPanel implements ParamAdjustingListener {
    private String channelName;
    private Collection<SliderSpinner> sliders = new ArrayList<SliderSpinner>();
    private Box box = Box.createVerticalBox();

    protected GrayScaleLookup adjustment = GrayScaleLookup.getDefaultAdjustment();
    protected static final int BLACK_DEFAULT = 0;
    protected static final int WHITE_DEFAULT = 255;
    private static final Color DARK_CYAN = new Color(0, 128, 128);
    private static final Color LIGHT_PINK = new Color(255, 128, 128);
    private static final Color DARK_PURPLE = new Color(128, 0, 128);
    private static final Color LIGHT_GREEN = new Color(128, 255, 128);
    private static final Color DARK_YELLOW_GREEN = new Color(128, 128, 0);
    private static final Color LIGHT_BLUE = new Color(128, 128, 255);
    private static final Color DARK_BLUE = new Color(0, 0, 128);
    private static final Color LIGHT_YELLOW = new Color(255, 255, 128);
    private static final Color DARK_GREEN = new Color(0, 128, 0);
    private static final Color LIGHT_PURPLE = new Color(255, 128, 255);
    private static final Color DARK_RED = new Color(128, 0, 0);
    private static final Color LIGHT_CYAN = new Color(128, 255, 128);

    protected SliderSpinner inputBlackSlider;
    protected SliderSpinner inputWhiteSlider;
    protected SliderSpinner outputBlackSlider;
    protected SliderSpinner outputWhiteSlider;
    protected final GrayScaleAdjustmentChangeListener grayScaleAdjustmentChangeListener;

    public OneChannelLevelsPanel(Type type, GrayScaleAdjustmentChangeListener grayScaleAdjustmentChangeListener) {

        this.channelName = type.getName();
        this.grayScaleAdjustmentChangeListener = grayScaleAdjustmentChangeListener;
        add(box);


        RangeParam inputBlackParam = new RangeParam("Input Dark", 0, 255, BLACK_DEFAULT);
        inputBlackParam.setAdjustingListener(this);
        inputBlackSlider = new SliderSpinner(Color.GRAY, type.getBackColor(), inputBlackParam);

        RangeParam inputWhiteParam = new RangeParam("Input Light", 0, 255, WHITE_DEFAULT);
        inputWhiteParam.setAdjustingListener(this);
        inputWhiteSlider = new SliderSpinner(type.getWhiteColor(), Color.GRAY, inputWhiteParam);

        RangeParam outputBlackParam = new RangeParam("Output Dark", 0, 255, BLACK_DEFAULT);
        outputBlackParam.setAdjustingListener(this);
        outputBlackSlider = new SliderSpinner(Color.GRAY, type.getWhiteColor(), outputBlackParam);

        RangeParam outputWhiteParam = new RangeParam("Output Light", 0, 255, WHITE_DEFAULT);
        outputWhiteParam.setAdjustingListener(this);
        outputWhiteSlider = new SliderSpinner(type.getBackColor(), Color.GRAY, outputWhiteParam);

        addSliderSpinner(inputBlackSlider);
        addSliderSpinner(inputWhiteSlider);
        addSliderSpinner(outputBlackSlider);
        addSliderSpinner(outputWhiteSlider);
    }


    public String getChannelName() {
        return channelName;
    }

    public void resetToDefaultSettings() {
        for (SliderSpinner slider : sliders) {
            slider.resetToDefaultSettings();
        }
        updateAdjustment();
    }

    public void addSliderSpinner(SliderSpinner sp) {
        box.add(sp);
        sliders.add(sp);
    }

    public GrayScaleLookup getAdjustment() {
        return adjustment;
    }

    @Override
    public void paramAdjusted() {
        updateAdjustment();

        grayScaleAdjustmentChangeListener.grayScaleAdjustmentHasChanged();
    }

    private void updateAdjustment() {
        int inputBlackValue = inputBlackSlider.getCurrentValue();
        int inputWhiteValue = inputWhiteSlider.getCurrentValue();
        int outputBlackValue = outputBlackSlider.getCurrentValue();
        int outputWhiteValue = outputWhiteSlider.getCurrentValue();

        adjustment = new GrayScaleLookup(inputBlackValue, inputWhiteValue, outputBlackValue, outputWhiteValue);
    }

    enum Type {
        RGB {
            @Override
            public String getName() {
                return "Red, Green, Blue";
            }
            @Override
            Color getBackColor() {
                return Color.BLACK;
            }
            @Override
            Color getWhiteColor() {
                return Color.WHITE;
            }
        }, R {
            @Override
            public String getName() {
                return "Red";
            }
            @Override
            Color getBackColor() {
                return DARK_CYAN;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_PINK;
            }
        }, G {
            @Override
            public String getName() {
                return "Green";
            }
            @Override
            Color getBackColor() {
                return DARK_PURPLE;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_GREEN;
            }
        }, B {
            @Override
            public String getName() {
                return "Blue";
            }
            @Override
            Color getBackColor() {
                return DARK_YELLOW_GREEN;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_BLUE;
            }
        }, RG {
            @Override
            public String getName() {
                return "Red, Green";
            }
            @Override
            Color getBackColor() {
                return DARK_BLUE;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_YELLOW;
            }
        }, RB {
            @Override
            public String getName() {
                return "Red, Blue";
            }
            @Override
            Color getBackColor() {
                return DARK_GREEN;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_PURPLE;
            }
        }, GB {
            @Override
            public String getName() {
                return "Green, Blue";
            }
            @Override
            Color getBackColor() {
                return DARK_RED;
            }
            @Override
            Color getWhiteColor() {
                return LIGHT_CYAN;
            }
        };

        abstract String getName();

        abstract Color getBackColor();

        abstract Color getWhiteColor();
    }
}
