/*
 * Copyright 2009-2010 L�szl� Bal�zs-Cs�ki
 *
 * This file is part of Pixelitor. Pixelitor is free software: you
 * can redistribute it and/or modify it under the terms of the GNU
 * General Public License, version 3 as published by the Free
 * Software Foundation.
 *
 * Pixelitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Pixelitor.  If not, see <http://www.gnu.org/licenses/>.
 */
package pixelitor.operations.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * A fixed set of GUIParam objects
 */
public class ParamSet implements Iterable<GUIParam> {
    private List<GUIParam> paramList = new ArrayList<GUIParam>();

    public ParamSet(GUIParam... params) {
        paramList.addAll(Arrays.asList(params));
        init();
    }

    public ParamSet(GUIParam param) {
        paramList.add(param);
        init();
    }

    private void init() {
        if(paramList.size() > 1) {
            addRandomizeAction();
            addResetAllAction();
        }
    }


    public void addRandomizeAction() {
        ActionParam randomizeAction = new ActionParam("Randomize Settings", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                randomize();
            }
        });
        paramList.add(randomizeAction);
    }

    public void addResetAllAction() {
        ActionParam randomizeAction = new ActionParam("Reset All", new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                reset(true);
            }
        }, "default_icon.gif");
        paramList.add(randomizeAction);
    }

    @Override
    public Iterator<GUIParam> iterator() {
        return paramList.iterator();
    }

    public void reset(boolean triggerAction) {
        for (GUIParam param : paramList) {
            param.reset(false);
        }
    }

    public void randomize() {
        for (GUIParam param : paramList) {
            param.randomize();
        }
    }
}
