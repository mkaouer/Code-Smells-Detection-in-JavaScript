/*
 * Copyright 2010 L�szl� Bal�zs-Cs�ki
 *
 * This file is part of Pixelitor. Pixelitor is free software: you
 * can redistribute it and/or modify it under the terms of the GNU
 * General Public License, version 3 as published by the Free
 * Software Foundation.
 *
 * Pixelitor is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Pixelitor.  If not, see <http://www.gnu.org/licenses/>.
 */
package pixelitor.operations.gui;

import pixelitor.utils.ImageUtils;

import javax.swing.*;
import java.awt.Color;

/**
 *
 */
public class ColorParam implements GUIParam {
    private ParamAdjustingListener adjustingListener;
    private String name;
    private Color defaultColor;
    private Color color;
    private boolean resetting = false;
    private ParamGUI paramGUI;

    public ColorParam(String name, Color defaultColor) {
        this.name = name + ":";
        this.defaultColor = defaultColor;
        this.color = defaultColor;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public boolean isSetToDefault() {
        return color.equals(defaultColor);
    }

    @Override
    public JComponent createControl() {
        ColorSelector gui = new ColorSelector(this);
        paramGUI = gui;
        return gui;
    }

    public void reset(boolean triggerAction) {
        if(!triggerAction) {
            resetting = true;
        }
        setColor(defaultColor);
        resetting = false;
    }

    @Override
    public void setAdjustingListener(ParamAdjustingListener listener) {
        this.adjustingListener = listener;
    }

    @Override
    public int getNrOfGUIWidgets() {
        return 2;
    }

    @Override
    public void randomize() {
        Color c = ImageUtils.getRandomColor();
        resetting = true;
        setColor(c);
        resetting = false;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color newColor) {
        if (newColor == null) {
            throw new IllegalArgumentException("newColor is null");
        }
        if(!color.equals(newColor)) {
            this.color = newColor;
            if(paramGUI != null) {
                paramGUI.updateGUI();
            }

            if(!resetting) {
                if(adjustingListener != null) {  // when called from randomize, this is null
                    adjustingListener.paramAdjusted();
                }
            }
        }
    }
}
