
#include "winview.h"
#include "ThisMfcApp.h"
#include "model.h"

View * WinView::_instance = 0;

int WinView::PromptUserForCombination()
{

	
	return 0;
}
